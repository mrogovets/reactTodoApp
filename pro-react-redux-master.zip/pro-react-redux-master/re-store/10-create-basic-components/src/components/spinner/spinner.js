import React from 'react';
import './spinner.css';

const Spinner = () => {
  return <div>loading...</div>;
};

export default Spinner;
