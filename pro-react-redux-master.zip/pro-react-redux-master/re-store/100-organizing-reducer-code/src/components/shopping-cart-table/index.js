import ShoppingCartTable from './shopping-cart-table';

export default ShoppingCartTable;
