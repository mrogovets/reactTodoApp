import BookListItem from './book-list-item';

export default BookListItem;
