import React from 'react';
import ReactDOM from 'react-dom';
import './main.scss';

const App = () => <p>This is WebPack React App</p>;

ReactDOM.render(<App/>, document.getElementById('root'));
