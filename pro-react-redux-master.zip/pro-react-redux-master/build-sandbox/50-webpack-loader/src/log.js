
export default class Log {

  log(msg) {
    console.log('============');
    console.log(msg);
    console.log('============');
  }
}
